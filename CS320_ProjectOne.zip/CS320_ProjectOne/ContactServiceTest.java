// Derek Braun
// Module 3 ContactServiceTest.java
// Date: 09.17.2021
// SNHU - CS 320


import java.util.Map;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



public class ContactServiceTest {
    
    public ContactServiceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    
    @Test
    public void testAddContact() {
        System.out.println("addContact");
        Contact contact = null;
        ContactService instance = new ContactService();
        Map<Integer, Contact> expResult = null;
        Map<Integer, Contact> result = instance.addContact(contact);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testDeleteContact() {
        System.out.println("deleteContact");
        String contactID = "";
        ContactService instance = new ContactService();
        Map<Integer, Contact> expResult = null;
        Map<Integer, Contact> result = instance.deleteContact(contactID);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testUpdateContact() {
        System.out.println("updateContact");
        String contactID = "";
        String firstName = "";
        String lastName = "";
        String Number = "";
        String Address = "";
        ContactService instance = new ContactService();
        Map<Integer, Contact> expResult = null;
        Map<Integer, Contact> result = instance.updateContact(contactID, firstName, lastName, Number, Address);
        assertEquals(expResult, result);
        
    }
    
}