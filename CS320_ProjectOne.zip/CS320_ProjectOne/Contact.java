// Derek Braun
// Module 3 Contact.java
// Date: 09.17.2021
// SNHU - CS 320

public class Contact{

    
    private String contactID;
    private String firstName;
    private String lastName;
    private String Address;
    private String Number;

    public Contact(String contactID, String firstName,String lastName,String Number, String Address) {
        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.Address = Address;
        this.Number = Number;
    }

    
    public String getContactID() {
        return contactID;
    }

   
    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }
    public String getNumber() {
        return Number;
    }

    public void setNumber(String Number) {
        this.Number = Number;
    }
     public boolean validateContactID(String contactID) {
        if (contactID != null && contactID.length() <= 10)
            return true;

        return false;
    }
    public boolean validatefirstName(String firstName) {
        if (firstName != null && firstName.length() <= 10)
            return true;

        return false;
    }
     public boolean validatelastName(String lastName) {
        if (lastName != null && lastName.length() <= 10)
            return true;

        return false;
    }
     public boolean validateNumber(String Number) {
        if (Number != null && Number.length() <= 10)
            return true;

        return false;
    }
     public boolean validateAddress(String Address) {
        if (Address != null && Address.length() <= 30)
            return true;

        return false;
    }
public static void main(String[] args)
{
    
}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
