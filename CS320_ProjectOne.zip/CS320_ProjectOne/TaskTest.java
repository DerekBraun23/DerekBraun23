/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Derek Braun
SNHU Module 4 task service project
10/12/2021
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
class TaskTest {
//tests the getters and followed by the setters.//
 @Test
 void testGetTaskId() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas and ticks");
 Assertions.assertEquals("123456789", task.getTaskId());
 }
 @Test
 void testGetName() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas and ticks");
 Assertions.assertEquals("checkChance", task.getName());
 }
 @Test
 void testGetDescription() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas and ticks");
 Assertions.assertEquals("checking Change for fleas and ticks", task.getDescription());
 }
//as mentioned above by the getters here the setters are tested.//
 @Test
 void testSetName() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas and ticks");
 task.setName("checkChance");
 Assertions.assertEquals("checkChance", task.getName());
 }
 @Test
 void testSetDescription() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas and ticks");
 task.setDescription("checking Chance for fleas and ticks");
 Assertions.assertEquals("checking Chance for fleas and ticks", task.getDescription());
 }
//test the length of string//
 @Test
 void testTaskIdTooLong() {
 Assertions.assertThrows(IllegalArgumentException.class,() -> new 
 Task("123456789","checkChance","checking Chance for fleas and ticks"));
 }
 @Test
 void testSetTooLongName() {
}Task task = new Task("123456789","checkChanceFleasTicksLong","checking Chance for fleas and ticks");
 Assertions.assertThrows(IllegalArgumentException.class,() -> task.setName("checkChanceFleasTicksLong"));
 }
 @Test
 void testSetTooLongDescription() {
 Task task = new Task("123456789","checkChanceFleasTicksLong","checking Chance for fleas and ticks character check 50 characters or more");
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> task.setDescription("checking Chance for fleas and ticks character check 50 characters or more"));
 }
//tests the TaskIdNull//
 @Test
 void testTaskIdNull() {
 Assertions.assertThrows(IllegalArgumentException.class,() -> new Task("123456789","checkChance","checking Chance for fleas and ticks"));
 }
 @Test
 void testTaskNameNull() {
 Task task = new Task("123456789","checkChance","checking Chance for fleasand ticks");
 Assertions.assertThrows(IllegalArgumentException.class,() -> task.setName(null));
 }
 @Test
 void testTaskDescriptionNull() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas and ticks");
 Assertions.assertThrows(IllegalArgumentException.class,() -> task.setDescription(null));
 }
} //end of the TaskTest class//
