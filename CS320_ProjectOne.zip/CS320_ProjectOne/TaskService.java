/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Derek Braun
 * SNHU CS 320 Module 4 Task Service Project
 * 10/12/2021
 */
import java.util.*;

public class TaskService {
    private final List<Task> listOfTask = new ArrayList<>();
    
    //randomly creates ans stores task id.//
    
private String newTaskID() {
    return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
}  

//checks if the task id exists or not.//

private Task searchForTask(String tid) throws Exception {    
    int i = 0;    
    while (i < listOfTask.size()) {
        if (tid.equals(listOfTask.get(i).getTaskId())) {
            return listOfTask.get(i);
        } 
        
} 
//end of the if-statement//
    
i++;    

//end of the while loop //   
    throw new Exception("task id is not found");
    }  
    public void addTask(String nm, String desc) {
        Task task = new Task(newTaskID(), nm, desc);
        listOfTask.add(task);
}  
    public void deleteTask(String tid) throws Exception {
        listOfTask.remove(searchForTask(tid));
}  

//updating the name or description  
    public void updateName(String tid, String nm) throws Exception {
        searchForTask(tid).setName(nm); 
    
}
    public void updateDescription(String tid, String desc)
        throws Exception {    
        searchForTask(tid).setDescription(desc);
        }  
    public List<Task> getlistOfTask() { return listOfTask; }
} 
//end the TaskService class.//