/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Derek Braun
 * SNHU CS 320 Module 4 Task Service Project
 * 10/12/2021
 */

public class Task {
    private String taskId; 
    private String name; 
  
    private String description; 
  
    public Task(String tid, String nm, String desc) {  
        if(tid == null || tid.length() > 10) {  
            throw new IllegalArgumentException("Invalid task id - null or length > 10");
        }  
        if(nm == null || nm.length() > 20) {
            throw new IllegalArgumentException("Invalid name - null or length > 20");
        }  
        if(desc == null || desc.length() > 50) {  
            throw new IllegalArgumentException("Invalid description - null or length > 50");
        }  
        this.taskId = tid;  
        this.name = nm;  
        this.description = desc;
    }  
//here are the getters.// 
    public String getTaskId() {   
        return taskId;
    }  
    public String getName() {
            return name;
}  
    public String getDescription() {
        return description;
}  
//end of getters // 
//now we have the setters.// 
    public void setTaskId(String tid) {
        if (tid == null || tid.length() > 10) {
            throw new IllegalArgumentException("task ID is invalid - null or length > 10");
    }     
        else {      
    this.taskId = tid;
        }  
    }  
    
    public void setName(String nm) {
        if (nm == null || nm.length() > 20) {
            throw new IllegalArgumentException("task name is invalid - null or length > 20");
        }     
        else {
            this.name = nm;
    }  
}     
    public void setDescription(String desc) {    
        if (desc == null || desc.length() > 50) {
            throw new IllegalArgumentException("task description is invalid - null or length > 50");
    }     
        else {      
            this.description = desc;
        }  
    }
} //end of Task class...
