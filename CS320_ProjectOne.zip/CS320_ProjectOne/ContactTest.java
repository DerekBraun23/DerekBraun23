// Derek Braun
// Module 3 ContactTest.java
// Date: 09.17.2021
// SNHU - CS 320

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    
    public ContactTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

   
    @Test // test
    public void testGetContactID() {
        System.out.println("getContactID");
        Contact instance = null;
        String expResult = "";
        String result = instance.getContactID();
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testSetContactID() {
        System.out.println("setContactID");
        String contactID = "";
        Contact instance = null;
        instance.setContactID(contactID);
        
    }

    
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        Contact instance = null;
        String expResult = "";
        String result = instance.getFirstName();
        assertEquals(expResult, result);
       
    }

    
    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String firstName = "";
        Contact instance = null;
        instance.setFirstName(firstName);
        
    }

   
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        Contact instance = null;
        String expResult = "";
        String result = instance.getLastName();
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String lastName = "";
        Contact instance = null;
        instance.setLastName(lastName);
        
    }

    
    @Test
    public void testGetAddress() {
        System.out.println("getAddress");
        Contact instance = null;
        String expResult = "";
        String result = instance.getAddress();
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testSetAddress() {
        System.out.println("setAddress");
        String Address = "";
        Contact instance = null;
        instance.setAddress(Address);
        
    }

  
    @Test
    public void testGetNumber() {
        System.out.println("getNumber");
        Contact instance = null;
        String expResult = "";
        String result = instance.getNumber();
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testSetNumber() {
        System.out.println("setNumber");
        String Number = "";
        Contact instance = null;
        instance.setNumber(Number);
        
    }

    
    @Test
    public void testValidateID() {
        System.out.println("validateID");
        String contactID = "";
        Contact instance = null;
        boolean expResult = false;
        boolean result = instance.validateContactID(contactID);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testValidatefirstName() {
        System.out.println("validatefirstName");
        String firstName = "";
        Contact instance = null;
        boolean expResult = false;
        boolean result = instance.validatefirstName(firstName);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testValidatelastName() {
        System.out.println("validatelastName");
        String lastName = "";
        Contact instance = null;
        boolean expResult = false;
        boolean result = instance.validatelastName(lastName);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testValidateNumber() {
        System.out.println("validateNumber");
        String Number = "";
        Contact instance = null;
        boolean expResult = false;
        boolean result = instance.validateNumber(Number);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testValidateAddress() {
        System.out.println("validateAddress");
        String Address = "";
        Contact instance = null;
        boolean expResult = false;
        boolean result = instance.validateAddress(Address);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Contact.main(args);
        
    }

    
   
    @Test
    public void testValidateContactID() {
        System.out.println("validateContactID");
        String contactID = "";
        Contact instance = null;
        boolean expResult = false;
        boolean result = instance.validateContactID(contactID);
        assertEquals(expResult, result);
        
    }
    
}
